#ifndef _UDPCLIENT_H_
#define _UDPCLIENT_H_

#include<iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <dirent.h>
#include<fstream>
#include<sstream>

#define BUF_SIZE 2048
#define port 8787
using namespace std;

struct frame_t{
    long int ID;
    long int length;
    char data[BUF_SIZE];
};

class udpclient{
    public:
     char str[INET_ADDRSTRLEN];
    struct sockaddr_in send_addr, from_addr;
    struct stat st;
    struct frame_t frame;
    struct timeval t_out={0,0};
    char cmd_send[50];
    char flname[20];
    char cmd[10];
    char ack_send[4]="ACK";
    FILE* fptr;
    ssize_t numRead=0;
    ssize_t length=0;
    off_t f_size=0;
    long int ack_num=0;
    int cfd, ack_recv=0;


    udpclient();    //constructor.
    ~udpclient();   //destructor.
};


#endif