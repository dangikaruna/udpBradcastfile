#include"../header/udpclient.h"

udpclient::udpclient(){
    memset(ack_send,0, sizeof(ack_send));
    memset(&send_addr,0, sizeof(send_addr));
    memset(&from_addr, 0, sizeof(from_addr));

/*

    ifstream filess;
    int port;
    std::string line;
    try{
        filess.open("../Resources/portinfo.config");
        while(getline(filess, line)){
            istringstream sin(line.substr(line.find("=")+1));
            if(line.find("Address")!=-1){
                sin>>str;
            }
            else if(line.find("port")!=-1){
                sin>>port;
            }
        }
    }catch(exception str){
        std::cout<<"sorry file not found exception....."<<std::endl;
    }

    inet_pton(AF_INET, str, &(send_addr.sin_addr));
    inet_ntop(AF_INET, &(send_addr.sin_addr), str, INET_ADDRSTRLEN);
*/
   int broadcast =1;
    bzero(&send_addr, sizeof(send_addr));
    send_addr.sin_family=AF_INET;
    send_addr.sin_port=htons(port);
    send_addr.sin_addr.s_addr=INADDR_BROADCAST;

    if((cfd=socket(AF_INET, SOCK_DGRAM,0))==-1)
        cerr<<"Client: socket: ";

	 if(setsockopt(cfd, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast)) <0)
   {
   
    perror("socket set error...\n");
    exit(-1);
   }
 

    for (;;) {

		memset(cmd_send, 0, sizeof(cmd_send));
		memset(cmd, 0, sizeof(cmd));
		memset(flname, 0, sizeof(flname));

		cout<<"\n 1.)FIND [file_name] \n 2.) exit \n";		
		scanf(" %[^\n]%*c", cmd_send);

		//printf("----> %s\n", cmd_send);
		
		sscanf(cmd_send, "%s %s", cmd, flname);		//parse the user input into command and filename

		if (sendto(cfd, cmd_send, sizeof(cmd_send), 0, (struct sockaddr *) &send_addr, sizeof(send_addr)) == -1) {
			cerr<<"Client: send";
		}
               if ((strcmp(cmd, "FIND") == 0) && (flname[0] != '\0' )) {

			long int total_frame = 0;
			long int bytes_rec = 0, i = 0;

			t_out.tv_sec = 2;
			setsockopt(cfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval)); 	//Enable the timeout option if client does not respond

			recvfrom(cfd, &(total_frame), sizeof(total_frame), 0, (struct sockaddr *) &from_addr, (socklen_t *) &length); //Get the total number of frame to recieve

			t_out.tv_sec = 0;
                	setsockopt(cfd, SOL_SOCKET, SO_RCVTIMEO, (char *)&t_out, sizeof(struct timeval)); 	//Disable the timeout option
			
			if (total_frame > 0) {
				sendto(cfd, &(total_frame), sizeof(total_frame), 0, (struct sockaddr *) &send_addr, sizeof(send_addr));
				cout<<"Total frame---->"<<total_frame;
				
				fptr = fopen(flname, "wb");	//open the file in write mode

				/*Recieve all the frames and send the acknowledgement sequentially*/
				for (i = 1; i <= total_frame; i++)
				{
					memset(&frame, 0, sizeof(frame));

					recvfrom(cfd, &(frame), sizeof(frame), 0, (struct sockaddr *) &from_addr, (socklen_t *) &length);  //Recieve the frame
					sendto(cfd, &(frame.ID), sizeof(frame.ID), 0, (struct sockaddr *) &send_addr, sizeof(send_addr));	//Send the ack

					/*Drop the repeated frame*/
					if ((frame.ID < i) || (frame.ID > i))
						i--;
					else {
						fwrite(frame.data, 1, frame.length, fptr);   /*Write the recieved data to the file*/
						//cout<<"frame.ID ---> %ld	frame.length ---> %ld\n", frame.ID, frame.length;
						cout<<"Frame ID: "<<frame.ID<<" Frame length ---->"<<frame.length<<endl;;
                        bytes_rec += frame.length;
					}

					if (i == total_frame) {
						cout<<"File recieved\n";
					}
				}
				//cout<<"Total bytes recieved ---> %ld\n", bytes_rec;

				cout<<"Total bytes recieved ---->"<<bytes_rec<<endl;
                cout<<"Total bytes recieved: "<<bytes_rec<<endl;
				fclose(fptr);
			}
			else {
				cout<<"File is empty\n";
			}
		}
    }
}

udpclient::~udpclient(){
    cout<<"Object destroyed: "<<endl;
}
