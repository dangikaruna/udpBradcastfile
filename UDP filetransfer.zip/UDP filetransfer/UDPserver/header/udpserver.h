#ifndef _UDPSERVER_H_
#define _UDPSERVER_H_


#include<iostream>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <dirent.h>
#include<fstream>

#define BUF_SIZE 2048   //max buffer size.
#define port 8787    //port number.
using namespace std;

struct frame_t{
    long long ID;
    long long length;
    char data[BUF_SIZE];
};

class udpServer{
    public:
    struct sockaddr_in sv_addr, cl_addr;
    struct stat st;
    struct frame_t frame;
    struct timeval t_out={0,0};
    char msg_recv[BUF_SIZE];
    char flname_recv[20];
    char cmd_recv[10];

    ssize_t numRead;
    ssize_t length;
    off_t f_size;
    long int ack_num=0;         //recieve frame ack
    int ack_send=0;
    int sfd;

    udpServer();
    ~udpServer();
};

#endif